#List of Databases....
 
  
# Give the location of the file 
loc = ("dataset.xlsx") 
l2=[]
  
# To open Workbook 
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 
  
# For row 0 and column 0 

for i in range(1,sheet.nrows):
	l2.append([sheet.cell_value(i,1),sheet.cell_value(i,2)])'''


import xlrd 
  
# Give the location of the file 
loc = ("dataset.xlsx") 
l2=[]
  
# To open Workbook 
wb = xlrd.open_workbook(loc) 
sheet = wb.sheet_by_index(0) 
  
# For row 0 and column 0 

for i in range(1,sheet.nrows):
	l2.append([sheet.cell_value(i,1),sheet.cell_value(i,2)])

print(l2[1])



