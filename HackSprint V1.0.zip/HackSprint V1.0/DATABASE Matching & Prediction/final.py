
#MMCOE,Karvenagar,Pune
#Main code to find longitude and latitude of input address...
import requests

query1 = input()
l0=[]
l0.append(query1)
l1 = []
KEY = "wG3Yy04QpNE3oSXCUZG8t091eXU328AY" 
 
URL = "http://www.mapquestapi.com/geocoding/v1/address?key="+KEY+"&location="+query1
  
r = requests.get(url = URL) 
   
data = r.json()
 
 

longitude = data["results"][0]["locations"][0]["latLng"]["lat"] 
latitude = data["results"][0]["locations"][0]["latLng"]["lng"] 

  
# printing the output 
'''print("Latitude:%s\nLongitude:%s"
      %(latitude, longitude))'''
#append the longitude nad latitude in l1 of input address..
l1.append([latitude,longitude])
#.....................................................................................................................................

#taking top 5 address match with input address from database...
l2 = []
with open("SampleAddress1.txt") as file:   
                    data = file.read().split('\n')

from fuzzywuzzy import process



def matching_address(query,choices,limit=5):
        res=process.extract(query,choices,limit=limit)
        return res

a=matching_address(query1,data)        #input address to search in database.
for i in a:                           #converted list of tuple into list
	l2.append(i[0])

#.................................................................................................................................................
#now finding the longitudes and latitudes of top 5 serched address....
import requests
l3 = []

for i in l2:
	query1=i
	KEY = "wG3Yy04QpNE3oSXCUZG8t091eXU328AY"
	URL = "http://www.mapquestapi.com/geocoding/v1/address?key="+KEY+"&location="+query1
	r = requests.get(url = URL) 
	data = r.json()
	longitude = data["results"][0]["locations"][0]["latLng"]["lat"] 
	latitude = data["results"][0]["locations"][0]["latLng"]["lng"] 
	l3.append([i,latitude,longitude])
#...................................................................................................................................................
#comparing longitudes and latitudes of top 3 serched address with input address...
l4 = []
address = []
value = []
d={}


for i in range(len(l3)):
	d.update( {l3[i][0] : l3[i][1:]} )    #stored address and longitude,latitude in dictionary.

for i in d.values():
	if(i==l1[0]):
		l4.append(i)
 
l5 = []                                       #Again assigning address to the longitude and latitude.
for i in l4:
	l5.append(tuple((k for k,v in d.items() if v==i)))
	#l5.append(list(d.keys())[list(d.values()).index(i)])

l5 = list(dict.fromkeys(l5))            #to get unique keys from list
 
l6 = [item for t in l5 for item in t]      #converting list of tuple to list



with open('New_Input.txt','w') as f:    #Writing new addresses to File..
    for item in l6:
        f.write("%s\n" % item)
#.................................................................................................
#Again using fuzzywuzzy logic for sorted address..
l7 = []
query1 = input()
with open("New_Input.txt") as file:   
                    data = file.read().split('\n')

from fuzzywuzzy import process

def matching_address(query,choices,limit=1):
        res=process.extract(query,choices,limit=limit)
        return res

#str1=str(input('Enter the adress to be matched'))
a=matching_address(query1,data)
for i in a:                           #converted list of tuple into list
	l7.append(i[0])
print("\n")
if(l7[0]==l0[0]):
	print("************* YES *************** YES *************** YES *************** YES ****************** YES ****************")
else:
	print("************* NO *************** NO *************** NO *************** NO ****************** NO ****************")
print("\n")
#....................................................................................................

print("** Latitude and Longitude of input Address : ","\n",l1)
print("\n")
print("** Top Matched Addresses of input Address using string match","\n",l2)
print("\n")
print("** Latitude and Longitude of Top matched Address ","\n",l3)
print("\n")
print("** Top Matched Latitude and Longitude using Latitude,Longitude Matching","\n",l4)
print("\n")
print("** Addresses of Top Matched Latitude and Longitude","\n",l5)
print("\n")
print("** Again Addresses are matched using string-match","\n",l7)











		




