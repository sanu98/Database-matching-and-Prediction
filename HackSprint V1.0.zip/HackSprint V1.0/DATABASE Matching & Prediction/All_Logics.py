#fuzzy logic used to match string...
x = input()
l3 = []
with open("New_Input.txt") as file:   
                    data = file.read().split('\n')

from fuzzywuzzy import process
from fuzzywuzzy import fuzz


def matching_address(query,choices,limit=1):
        res=process.extract(query,choices,limit=limit)
        return res

#str1=str(input('Enter the adress to be matched'))
a=matching_address(x,data)

for i in a:
	l3.append(i[0])
print(l3)

print(fuzz.WRatio(input,x))

#.................................................................................................................................................
'''import requests
l4 = []
#query = '1, Old Court House Corner Tobacco House, 4Th Floor Kolkata West Bengal 700001 India'


for i in l3:
	query=i
	KEY = "wG3Yy04QpNE3oSXCUZG8t091eXU328AY"
	URL = "http://www.mapquestapi.com/geocoding/v1/address?key="+KEY+"&location="+query
	r = requests.get(url = URL) 
	data = r.json()
	longitude = data["results"][0]["locations"][0]["latLng"]["lat"] 
	latitude = data["results"][0]["locations"][0]["latLng"]["lng"] 
	l4.append([i,longitude,latitude])
print(l4)'''
#.............................................................................................................
#main logic to find latitude and longitude


#http://www.mapquestapi.com/geocoding/v1/address?key=KEY&location=Washington,DC
#import urllib.parse
#query = '1, Old Court House Corner Tobacco House, 4Th Floor Kolkata West Bengal 700001 India'

#x=urllib.parse.quote(query)

KEY = "wG3Yy04QpNE3oSXCUZG8t091eXU328AY"


# importing the requests library 
import requests 
  
# api-endpoint 
URL = "http://www.mapquestapi.com/geocoding/v1/address?key=wG3Yy04QpNE3oSXCUZG8t091eXU328AY&location=Washington,DC"
  
# location given here 
#location = "delhi technological university"
  
# defining a params dict for the parameters to be sent to the API 
#PARAMS = {'address':location} 
  
# sending get request and saving the response as response object 
r = requests.get(url = URL) 
  
# extracting data in json format 
data = r.json()
print() 
 
 
#data={results:}
#print(data) 

longitude = data["results"][0]["locations"][0]["latLng"]["lat"] 
latitude = data["results"][0]["locations"][0]["latLng"]["lng"] 

  
# printing the output 
print("Latitude:%s\nLongitude:%s"
      %(latitude, longitude)) 

#..................................................................................................................................
#MAin LAtest logic to find longitude nad latitude....


#query = '1, Old Court House Corner Tobacco House, 4Th Floor Kolkata West Bengal 700001 India'
query = input()
l1 = []

KEY = "wG3Yy04QpNE3oSXCUZG8t091eXU328AY"


# importing the requests library 
import requests 
  
# api-endpoint 
URL = "http://www.mapquestapi.com/geocoding/v1/address?key="+KEY+"&location="+query
  

  
# sending get request and saving the response as response object 
r = requests.get(url = URL) 
  
# extracting data in json format 
data = r.json()
 
 
 

#print(data) 

longitude = data["results"][0]["locations"][0]["latLng"]["lat"] 
latitude = data["results"][0]["locations"][0]["latLng"]["lng"] 

  
# printing the output 
print("Latitude:%s\nLongitude:%s"
      %(latitude, longitude)) 

l1.append([longitude,latitude])

print(l1[0])
