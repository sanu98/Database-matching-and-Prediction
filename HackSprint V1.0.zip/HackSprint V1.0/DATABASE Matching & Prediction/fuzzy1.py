x = input()
l3 = []
with open("New_Input.txt") as file:   
                    data = file.read().split('\n')

from fuzzywuzzy import process
from fuzzywuzzy import fuzz


def matching_address(query,choices,limit=1):
        res=process.extract(query,choices,limit=limit)
        return res

#str1=str(input('Enter the adress to be matched'))
a=matching_address(x,data)

for i in a:
	l3.append(i[0])
print(l3)

print(fuzz.WRatio(input,x))


	





























	
